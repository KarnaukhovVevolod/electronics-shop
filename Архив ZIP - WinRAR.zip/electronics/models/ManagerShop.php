<?php


namespace app\models;

use yii\db\ActiveRecord;
use app\models\ManagerOrder;

class ManagerShop extends ActiveRecord {
    
    public static function tableName() {
        return 'manager_shop_order';
        
    }
    
    public function attributeLabels() {
        return[
            'id'              => 'id',
            'login'           => 'Логин',
            'name'            => 'Имя',
            'surname'         => 'Фамилия',
            'telephone'       => 'Телефон',
            'order_number'    => 'Номер заказа',
            'date_order'      => 'Дата',
            'email'           => 'E-mail',
            
            'post_code'        => 'Почт. индекс',
            'type_delivery'    => 'Тип доставки',
            'point_delivery'   => 'Пункт выдачи',
            'region'           => 'Регион',
            'city'             => 'Город',
            'village_locality' => 'посёлок/насел.пункт',
            'street'           => 'Улица',
            'room'             => 'Дом',
            'flat'             => 'Квартира',
            'status_order'     => 'Статус заказа',
            'total_price_order'=> 'Общая цена заказа',
            'pay_order'        => 'Оплата заказа',
        ];
    }
    
    public function rules() {
        return[
            [['id','order_number'],'integer'],
            [['login', 'post_code', 'type_delivery',
                'status_order', 'city', 'name','surname'], 'string', 'max'=>30],
            [['region','room','email'], 'string', 'max' => 50],
            [['date_order'], 'string', 'min' => 2],
            [['point_delivery','village_locality','street'], 'string', 'max' => 100],
            [['flat','telephone'],'string', 'max' => 20],
            ['order_number','unique'],
            [['total_price_order'], 'string', 'max' => 15],
            [['pay_order'],'string', 'max' => 15],
        ];
    }
    
    public function getProductshop(){
        return $this->hasMany(ManagerOrder::className(), ['order_number'=>'order_number']);
    }
    
    public function mypagination($url){
        $url = explode('&', $url);
        
        $limit = 2;
        $all_order = ManagerShop::find();
        $d_count = $all_order->count();
        $delit = $d_count%$limit;
        
        //$start_n = 0; //Ссылка на первую страницу
        $start_product = 0;
        $number_first = 1;
        $number_last = ceil($d_count /$limit);
        $last_n = $number_last * $limit + 1 - $limit;
        if( count($url) > 1 )
        {
            $n_int = (int) $url[1];
            $current_n = $n_int;//Ccылка на текущую страницу
            if($n_int == $d_count)
            {
                $start_product = $n_int - $limit + 1;
            }
            else
            {
                $start_product = $n_int;
            }
        }
        else {
            $start_product = 0;
            $current_n = 0;
        }
        
        if($start_product < 0)
        {
            $start_product = 0;
        }
        
        $current_number = $current_n/$limit;
        //debug($current_n);
        //die();
        $current_number = ceil($current_number);
        if($current_number == 0)
        {
            $current_number = 1;
        }
        $next = 0 ;$prev = 0;
        if($current_number == 1)
        {
            $prev = 0;
        }
        if ($current_number == $number_last)
        {
            $next = 0;
        }
        if($current_number != 1 )
        {
            if( $current_number == 2 )// && $current_number == )
            {
                $prev = 0;
            }
            else
            {
                $prev = ($current_number * $limit) - (2 * $limit) + 1;
            }
        }
        if($current_number != $number_last)
        {
            if( $current_number == $number_last - 1 )
            {
                $next = 0;
            }
            else
            {
                $next = $current_number * $limit + 1;
            }
            
        }
        //debug($prev);
        //debug($next);
        //debug($number_first);
        //debug($number_last);
        //debug($current_number);
        
        //die();
        
        return compact('start_product', 'limit', 'current_number',
               'number_first', 'number_last', 'prev', 'next', 'last_n');
    }
    
}
