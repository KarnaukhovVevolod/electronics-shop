<?php

namespace app\controllers;

use yii\web\Controller as Controller;

class AppController extends Controller
{
    //put your code here 
    
}
