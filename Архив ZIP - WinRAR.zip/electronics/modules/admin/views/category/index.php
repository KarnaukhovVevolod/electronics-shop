<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Все записи';
$this->params['breadcrumbs'][] = $this->title;
?>

<!-- ===== Выводим табличку категории ===== -->
<div class="form_my">

    <h1><?= Html::encode($this->title .' Категории') ?></h1>

    <p>
        <?= Html::a('Создать новую запись', ['create','section'=>'category','my_seo_category'=>'category'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            'category',
            'subcategory',
            'type_of_subcategory',
            'category_english',
            'link_category',
            'link_subcategory',
            'link_type_subcategory',
            'id_seo_search_category',
            'id_seo_search_subcategory',
            'id_seo_search_type_of_subcategory',
            
            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update} {delete} {link}',
                'template' =>'{view}{update} {delete}',
                'buttons' => [
                    'view'   => function ($url, $model, $key) {
                        $view = Html::a('',['/admin/category/view','id'=>$model['id'],'section'=>'category','my_seo_category'=>'category'],
                                ['class' => 'glyphicon glyphicon-eye-open']);
                        return $view;
                    },
                    'update' => function ($url, $model, $key) {
                        $update = Html::a('',['/admin/category/update','id'=>$model['id'],'section'=>'category','my_seo_category'=>'category'], 
                                ['class' => 'glyphicon glyphicon-pencil']);                       
                        return $update; 
                    },
                    'delete' => function ($url, $model, $key) {
                        $delete = Html::a('',['/admin/category/delete','id'=>$model['id'],'section'=>'category','my_seo_category'=>'category'], 
                                ['class' => 'glyphicon glyphicon-trash']);                       
                        return $delete; 
                    },
                ],
            ],
        ],
    ]); ?>


</div>
<?php// break; ?>

<?php// case('search'): ?>

<!-- ===== Выводим табличку с seo-данными для главной страницы,страницы о компании и т.д.  ===== -->

<div class="form_my">

    <h1><?= Html::encode($this->title.' Главная страница и т.д.') ?></h1>

    <p>
        <?= Html::a('Создать новую запись', ['create','section'=>'search','my_seo_category'=>'main_page'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider_1,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'teg_title',
                'label'     => 'Tег title',
            ],
            [
                'attribute' => 'teg_keywords',
                'label'     => 'Тег keywords',
            ],
            [
                'attribute' => 'teg_description',
                'label'     => 'Тег description',
            ],
            [
                'attribute' => 'my_comment',
                'label'     => 'Мои комментарии',
            ],
            [
                'attribute' => 'type_category',
                'label'     => 'Страницы: главная, о нас , наш адрес',
                'content'   => function($data){
                    
                    switch ($data['type_category']){
                        case 'main':
                            return 'Главная страница';
                            break;
                        case 'about_us':
                            return 'Страница о компании';
                            break;
                        case 'office_addresses':
                            return 'Страница адреса офисов';
                            break;
                        default :
                            return $data['type_category'];
                            break;
                    }
                    /**/
                    //return '$data';
                }
            ],
            
            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update} {delete} {link}',
                'template' =>'{view}{update} {delete}',
                'buttons' => [
                    'view'   => function ($url, $model, $key) {
                        $view = Html::a('',['/admin/category/view','id'=>$model['id'],'section'=>'search','my_seo_category'=>'main_page'],
                                ['class' => 'glyphicon glyphicon-eye-open']);
                        return $view;
                    },
                    'update' => function ($url, $model, $key) {
                        $update = Html::a('',['/admin/category/update','id'=>$model['id'],'section'=>'search','my_seo_category'=>'main_page'], 
                                ['class' => 'glyphicon glyphicon-pencil']);                       
                        return $update; 
                    },
                    'delete' => function ($url, $model, $key) {
                        $delete = Html::a('',['/admin/category/delete','id'=>$model['id'],'section'=>'search','my_seo_category'=>'main_page'], 
                                ['class' => 'glyphicon glyphicon-trash']);                       
                        return $delete; 
                    },
                ],
            ],
        ]
    ]); ?>


</div>

<!-- ===== Выводим табличку с seo-данными для страницы с категориями -->
<div class="form_my">

    <h1><?= Html::encode($this->title.' Для категорий ') ?></h1>

    <p>
        <?= Html::a('Создать новую запись', ['create','section'=>'search_category','my_seo_category'=>'search_category'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider_2,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'teg_title',
                'label'     => 'Tег title',
            ],
            [
                'attribute' => 'teg_keywords',
                'label'     => 'Тег keywords',
            ],
            [
                'attribute' => 'teg_description',
                'label'     => 'Тег description',
            ],
            [
                'attribute' => 'my_comment',
                'label'     => 'Мои комментарии',
            ],
            
            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update} {delete} {link}',
                'template' =>'{view}{update} {delete}',
                'buttons' => [
                    'view'   => function ($url, $model, $key) {
                        $view = Html::a('',['/admin/category/view','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_category'],
                                ['class' => 'glyphicon glyphicon-eye-open']);
                        return $view;
                    },
                    'update' => function ($url, $model, $key) {
                        $update = Html::a('',['/admin/category/update','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_category'], 
                                ['class' => 'glyphicon glyphicon-pencil']);                       
                        return $update; 
                    },
                    'delete' => function ($url, $model, $key) {
                        $delete = Html::a('',['/admin/category/delete','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_category'], 
                                ['class' => 'glyphicon glyphicon-trash']);                       
                        return $delete; 
                    },
                ],
            ],
        ]
    ]); ?>


</div>

<!-- ===== Выводим табличку с seo-данными для страницы с подкатегориями -->
<div class="form_my">

    <h1><?= Html::encode($this->title. ' Для подкатегорий') ?></h1>

    <p>
        <?= Html::a('Создать новую запись', ['create','section'=>'search_category','my_seo_category'=>'search_subcategory'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider_3,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'teg_title',
                'label'     => 'Tег title',
            ],
            [
                'attribute' => 'teg_keywords',
                'label'     => 'Тег keywords',
            ],
            [
                'attribute' => 'teg_description',
                'label'     => 'Тег description',
            ],
            [
                'attribute' => 'my_comment',
                'label'     => 'Мои комментарии',
            ],
            
            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update} {delete} {link}',
                'template' =>'{view}{update} {delete}',
                'buttons' => [
                    'view'   => function ($url, $model, $key) {
                        $view = Html::a('',['/admin/category/view','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_subcategory'],
                                ['class' => 'glyphicon glyphicon-eye-open']);
                        return $view;
                    },
                    'update' => function ($url, $model, $key) {
                        $update = Html::a('',['/admin/category/update','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_subcategory'], 
                                ['class' => 'glyphicon glyphicon-pencil']);                       
                        return $update; 
                    },
                    'delete' => function ($url, $model, $key) {
                        $delete = Html::a('',['/admin/category/delete','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_subcategory'], 
                                ['class' => 'glyphicon glyphicon-trash']);                       
                        return $delete; 
                    },
                ],
            ],
        ]
    ]); ?>


</div>

<!-- ===== Выводим табличку с seo-данными для страницы с типами подкатегориями -->
<div class="form_my">

    <h1><?= Html::encode($this->title.' Для типов подкатегорий') ?></h1>

    <p>
        <?= Html::a('Создать новую запись', ['create','section'=>'search_category','my_seo_category'=>'search_type_of_subcategory'], ['class' => 'btn btn-success']) ?>
    </p>


    <?= GridView::widget([
        'dataProvider' => $dataProvider_4,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'teg_title',
                'label'     => 'Tег title',
            ],
            [
                'attribute' => 'teg_keywords',
                'label'     => 'Тег keywords',
            ],
            [
                'attribute' => 'teg_description',
                'label'     => 'Тег description',
            ],
            [
                'attribute' => 'my_comment',
                'label'     => 'Мои комментарии',
            ],
            
            [
                'class' => 'yii\grid\ActionColumn',
                //'template' => '{view} {update} {delete} {link}',
                'template' =>'{view}{update} {delete}',
                'buttons' => [
                    'view'   => function ($url, $model, $key) {
                        $view = Html::a('',['/admin/category/view','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_type_of_subcategory'],
                                ['class' => 'glyphicon glyphicon-eye-open']);
                        return $view;
                    },
                    'update' => function ($url, $model, $key) {
                        $update = Html::a('',['/admin/category/update','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_type_of_subcategory'], 
                                ['class' => 'glyphicon glyphicon-pencil']);                       
                        return $update; 
                    },
                    'delete' => function ($url, $model, $key) {
                        $delete = Html::a('',['/admin/category/delete','id'=>$model['id'],'section'=>'search_category','my_seo_category'=>'search_type_of_subcategory'], 
                                ['class' => 'glyphicon glyphicon-trash']);                       
                        return $delete; 
                    },
                ],
            ],
        ]
    ]); ?>


</div>











