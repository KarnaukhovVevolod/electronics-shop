<?php

namespace app\modules\user\controllers;

use yii\web\Controller;
/**
 * Description of AppUserControllers
 *
 * @author Seva
 */
class AppUserController extends Controller {
    
}
